﻿namespace $safeprojectname$.Helpers
{
  public static class PageTokens
  {
    public const string MAIN_PAGE = "Main";
  }
}